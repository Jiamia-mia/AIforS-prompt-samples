# TerminalBench 任务包说明

这个压缩包里有两个任务，目录结构相同：

```
3283/   — ThermoML 同系物蒸气压预测（化学）
co2/    — 碱性 CO2 电解槽动力学参数拟合（电化学）
```

每个任务目录下都是：

```
<task>/
├── instruction.md      给被测模型（agent）看的任务描述
├── task.toml           任务配置：名称、分类、超时、资源、网络、判分环境变量等
├── environment/        agent 运行的容器
│   ├── Dockerfile
│   └── data/           输入数据，构建时复制进容器的 /app 下
├── solution/           参考解（golden solution）
│   └── solve.sh        入口脚本，调用同目录下的 Python 脚本
└── tests/              判分器（verifier）
    ├── Dockerfile      判分容器
    ├── test.sh         判分入口，写出 reward
    ├── test_outputs.py pytest 测试
    └── ...             参考值和判分用的数据副本
```

## 各部分是干什么的

**instruction.md**：任务本身，也就是发给 agent 的提示词。它说明要做什么、输入在哪、输出写到哪、成功的标准是什么。这份文件必须由作者本人撰写。

**environment/**：agent 工作的“机器”。用 `environment/Dockerfile` 构建一个 Ubuntu 容器，装好允许使用的工具（Python、numpy 等），再把 `data/` 里的输入文件放到 `/app` 下：

| 任务 | agent 能看到的输入 |
|---|---|
| 3283 | `/app/data/thermoml_vapor_pressure.json` |
| co2 | `/app/electrolysis_experiments.xlsx`、`/app/experimental_setup.md`、`/app/parameter.md` |

这个环境里不能出现答案、参考解或判分逻辑。

**solution/**：作者的参考解，用来证明任务可解。它只用 agent 同样能拿到的输入算出结果，不能硬编码答案。`rv oracle` 会在 environment 容器里运行 `solution/solve.sh`，再交给判分器判分，必须拿到满分。

**tests/**：判分器。它在一个**独立的**判分容器里运行（`task.toml` 里 `environment_mode = "separate"`），agent 看不到也改不了。判分器只读取 agent 产出的结果文件，并和参考值或独立重算的结果比较。

**task.toml**：把以上几部分串起来的配置，包括：
- 分类（category / subcategory）；
- agent、判分和构建的超时；
- CPU、内存和网络限制；
- `artifacts`：需要从 agent 容器带到判分容器的结果文件；
- `[verifier.env]`：判分用的环境变量。

## 逐个文件说明

“谁能看到”一列表示这个文件在评测时由谁使用：
- **agent**：被测模型在 environment 容器里能看到
- **oracle**：只在 `rv oracle` 跑参考解时使用
- **判分**：只在独立的判分容器里使用

### 两个任务共有的文件

| 文件 | 作用 | 谁能看到 |
|---|---|---|
| `instruction.md` | 任务描述（提示词）：要做什么、输入在哪、输出写到哪、格式和成功标准 | agent |
| `task.toml` | 任务配置：名称、分类、难度说明、超时、CPU/内存、网络、`artifacts`（要交给判分的结果文件）、`[verifier.env]` | 平台读取，agent 看不到 |
| `environment/Dockerfile` | 构建 agent 容器：Ubuntu 基础镜像 + 固定版本的 Python 包，把 `data/` 复制到 `/app` | 平台构建 |
| `environment/data/*` | 任务输入数据 | agent |
| `solution/solve.sh` | 参考解入口，`rv oracle` 在 agent 容器里运行它 | oracle |
| `tests/Dockerfile` | 构建判分容器：python:3.11-slim + pytest/numpy（co2 另加 scipy） | 判分 |
| `tests/test.sh` | 判分入口：先写 reward 0，运行 pytest，全部通过才改写为 1，写入 `/logs/verifier/reward.txt` | 判分 |
| `tests/test_outputs.py` | 具体的 pytest 检查项 | 判分 |
| `tests/ref_values.json` | 参考答案或可接受范围 | 判分 |

### 3283 特有的文件

| 文件 | 作用 |
|---|---|
| `environment/data/thermoml_vapor_pressure.json` | ThermoML 蒸气压数据，包含要预测的保留点（target ID），放在 `/app/data/` |
| `solution/solve.py` | 参考解：用同系物邻居和温度曲线预测保留点的蒸气压，写到 `/app/results/answer.json` |
| `tests/ref_values.json` | 每个 target ID 的真实蒸气压（kPa） |
| `task.toml` 的 `[verifier.env]` | `REF_SERIES`（target 属于哪个家族）和单点误差上限，判分时读取 |

### co2 特有的文件

| 文件 | 作用 |
|---|---|
| `environment/data/electrolysis_experiments.xlsx` | 24 组电压扫描实验（KOH 和 Carbonate 两个 sheet），放在 `/app/` |
| `environment/data/experimental_setup.md` | 实验装置和条件说明 |
| `environment/data/parameter.md` | 已知物性参数（扩散系数、ΔfG° 等） |
| `solution/fit.py` | 参考解主程序：由 ΔfG° 算 K1、K2，拟合 k1f、k2f、j0，写 `/app/result.json` |
| `solution/model.py` | 液膜反应-传质有限体积模型（Nernst–Planck + Butler–Volmer + 碳酸盐反应） |
| `solution/xlsx_io.py` | 不依赖 openpyxl 的 xlsx 读取工具 |
| `tests/model.py` | 判分用的同一模型副本，只把牛顿迭代上限改成可调（60，重试时 600） |
| `tests/xlsx_io.py` | 判分用的 xlsx 读取工具 |
| `tests/electrolysis_experiments.xlsx`、`tests/parameter.md` | 判分用的数据副本，agent 修改 `/app` 下的文件不影响判分 |
| `tests/ref_values.json` | 五个动力学参数的可接受范围 |

## 测试模型时用哪个

agent **只拿到 `instruction.md` 和 `environment/` 构建出的容器**。它在容器里探索文件、写代码、跑计算，最后把结果写到 instruction 指定的位置：

| 任务 | agent 需要写出的结果 |
|---|---|
| 3283 | `/app/results/answer.json` |
| co2 | `/app/result.json` |

`solution/` 和 `tests/` 对 agent 完全不可见。

## 判分时用什么

agent 结束后：

1. 按 `task.toml` 的 `artifacts` 把结果文件交给判分容器（用 `tests/Dockerfile` 构建）。
2. 运行 `tests/test.sh`，它会调用 `pytest tests/test_outputs.py`。
3. 所有测试通过，就往 `/logs/verifier/reward.txt` 写 `1`；任何一项失败都写 `0`。没有部分分。

两个任务的判分内容不同。

**3283**：用 `tests/ref_values.json` 里的真实蒸气压，以及 `task.toml` 里 `[verifier.env]` 的分组（`REF_SERIES`）和误差上限，计算 MALE，检查以下几项：
- 13 个同系物家族的平均 MALE ≤ 0.090；
- 两个多温度家族各自的上限；
- 单点误差上限。

**co2**：判分器用 tests/ 里自带的 `model.py`、`electrolysis_experiments.xlsx` 和 `parameter.md`，代入 agent 提交的五个参数独立重算 24 组实验，依次检查：
- 输出格式；
- k1f/k1b、k2f/k2b 与 ΔfG° 算出的 K1、K2 偏差 ≤ 1%；
- 重算和上报的 weighted_RMSE 都 ≤ 1.2，且两者相差 ≤ 0.01；
- 五个参数都落在 `tests/ref_values.json` 的范围内。

判分用的数据全部从 `tests/` 里读，agent 修改 `/app` 下的输入文件不会影响判分。

## 常用 rv 命令对应关系

| 命令 | 用到的部分 |
|---|---|
| `rv oracle` | environment + solution → tests（验证参考解能拿满分） |
| `rv run -k 8` | environment + instruction.md → 模型作答 → tests 判分 |
| `rv check` / `rv probe` | 检查配置是否合法、是否泄题、判分器能否被绕过 |
