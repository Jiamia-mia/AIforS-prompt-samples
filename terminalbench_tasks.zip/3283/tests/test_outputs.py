#!/usr/bin/env python3
"""Grade pressure predictions using explicit public series identifiers."""
from __future__ import annotations

import json
import math
import os
import sys

import pytest
from pathlib import Path

OUTPUT = "/app/results/answer.json"
MAX_CASE_BALANCED_MALE = 0.090
FAMILY_LIMITS = {"S_RBGYMTWW": 0.06, "S_2S5AB6WB": 0.090}
DEFAULT_INDIVIDUAL_CAP = float(os.environ["MAX_INDIVIDUAL_LOG_ERROR"])
INDIVIDUAL_CAPS = {"S_2S5AB6WB": float(os.environ["MAX_DIAMINE_INDIVIDUAL_LOG_ERROR"])}


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    sys.exit(1)


def _measure():
    if not os.path.isfile(OUTPUT):
        fail(f"missing {OUTPUT}")
    try:
        with open(OUTPUT, encoding="utf-8") as handle:
            document = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        fail(f"invalid JSON: {exc}")
    if not isinstance(document, dict) or set(document) != {"predictions"}:
        fail("top-level object must contain exactly the predictions field")
    if not isinstance(document["predictions"], list):
        fail("predictions must be a list")
    try:
        with (Path(__file__).resolve().parent / "ref_values.json").open(encoding="utf-8") as handle:
            references = {target: float(value) for target, value in json.load(handle).items()}
        cases = json.loads(os.environ["REF_SERIES"])
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        fail(f"invalid verifier reference: {exc}")
    if (not isinstance(cases, dict) or len(cases) != 13 or
        any(not isinstance(sid, str) or not isinstance(ids, list) or not ids for sid, ids in cases.items()) or
        any(not isinstance(target, str) for ids in cases.values() for target in ids)):
        fail("invalid verifier series grouping")
    grouped = [target for ids in cases.values() for target in ids]
    if len(grouped) != len(set(grouped)) or set(grouped) != set(references):
        fail("verifier series must partition the reference targets")
    for sid in FAMILY_LIMITS:
        if sid not in cases:
            fail(f"missing verifier series {sid}")
    submitted = {}
    for index, row in enumerate(document["predictions"]):
        if not isinstance(row, dict) or set(row) != {"target_id", "vapor_pressure_kPa"}:
            fail(f"prediction {index} has incorrect fields")
        target = row["target_id"]
        if not isinstance(target, str) or not target:
            fail(f"prediction {index} has invalid target_id")
        if target in submitted:
            fail(f"duplicate target_id: {target}")
        raw_pressure = row["vapor_pressure_kPa"]
        if isinstance(raw_pressure, bool) or not isinstance(raw_pressure, (int, float)):
            fail(f"pressure must be a JSON number for {target}")
        try:
            pressure = float(row["vapor_pressure_kPa"])
        except (TypeError, ValueError):
            fail(f"non-numeric pressure for {target}")
        if not math.isfinite(pressure) or pressure <= 0:
            fail(f"pressure must be positive and finite for {target}")
        submitted[target] = pressure
    if set(submitted) != set(references):
        fail(f"target mismatch; missing={sorted(set(references) - set(submitted))}, unexpected={sorted(set(submitted) - set(references))}")
    errors = {target: abs(math.log(submitted[target] / value)) for target, value in references.items()}
    males = {sid: sum(errors[target] for target in ids) / len(ids) for sid, ids in cases.items()}
    balanced = sum(males.values()) / len(males)
    return errors, males, balanced, cases


def main() -> None:
    errors, males, balanced, cases = _measure()
    print(f"case-balanced MALE={balanced:.9f}")
    for sid in sorted(cases):
        cap = INDIVIDUAL_CAPS.get(sid, DEFAULT_INDIVIDUAL_CAP)
        worst = max(cases[sid], key=errors.get)
        print(f"{sid}: MALE={males[sid]:.9f}; maximum={errors[worst]:.9f} ({worst}); individual cap={cap:.3f}")
        if sid in FAMILY_LIMITS and males[sid] > FAMILY_LIMITS[sid]:
            fail(f"series {sid} MALE {males[sid]:.9f} exceeds {FAMILY_LIMITS[sid]:.3f}")
        if errors[worst] > cap:
            fail(f"series {sid} individual log error {errors[worst]:.9f} for {worst} exceeds {cap:.3f}")
    if balanced > MAX_CASE_BALANCED_MALE:
        fail(f"case-balanced MALE {balanced:.9f} exceeds {MAX_CASE_BALANCED_MALE:.3f}")
    print("PASS")


@pytest.fixture(scope="session")
def measured_results():
    return _measure()


def test_case_balanced_pressure_predictions(measured_results):
    _, _, balanced, _ = measured_results
    assert balanced <= MAX_CASE_BALANCED_MALE


def test_rbgymtww_series_pressure_predictions(measured_results):
    _, males, _, _ = measured_results
    assert males["S_RBGYMTWW"] <= FAMILY_LIMITS["S_RBGYMTWW"]


def test_2s5ab6wb_series_pressure_predictions(measured_results):
    _, males, _, _ = measured_results
    assert males["S_2S5AB6WB"] <= FAMILY_LIMITS["S_2S5AB6WB"]


@pytest.mark.parametrize("series", sorted(json.loads(os.environ["REF_SERIES"])))
def test_individual_pressure_limits(measured_results, series):
    errors, _, _, cases = measured_results
    cap = INDIVIDUAL_CAPS.get(series, DEFAULT_INDIVIDUAL_CAP)
    assert max(errors[target] for target in cases[series]) <= cap


if __name__ == "__main__":
    main()
