#!/usr/bin/env bash
set -uo pipefail

mkdir -p /logs/verifier
echo 0 >/logs/verifier/reward.txt

python3 -I -m pytest /tests/test_outputs.py -rA 2>&1 | tee /logs/verifier/verifier.log
if [ "${PIPESTATUS[0]}" -eq 0 ]; then
  echo 1 >/logs/verifier/reward.txt
fi
