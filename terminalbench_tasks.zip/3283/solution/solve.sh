#!/usr/bin/env bash
set -euo pipefail

mkdir -p /app/results
python3 /solution/solve.py
