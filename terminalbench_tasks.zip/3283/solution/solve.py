#!/usr/bin/env python3
"""Predict held-out vapor pressures from neighboring homologues."""

from __future__ import annotations

import json
import math
import os
import argparse
from pathlib import Path
from statistics import NormalDist

import numpy as np

DATA = os.environ.get("DATA_DIR", "/app/data")
OUT = os.environ.get("OUT", "/app/results/answer.json")


def fitted_log_pressure(
    rows: list[dict], temperature: float, degree: int = 1
) -> float:
    """Fit log pressure as a polynomial in reciprocal temperature."""
    x = [1.0 / row["temperature_K"] for row in rows]
    y = [math.log(row["vapor_pressure_kPa"]) for row in rows]
    coefficients = np.polynomial.Polynomial.fit(x, y, degree)
    return float(coefficients(1.0 / temperature))


# Every series uses this same ordered candidate set and selection rule.
# Thermal curvature includes reciprocal-temperature polynomials and the
# Clarke–Glew basis; structural curvature captures changing homolog increments.
CANDIDATES = tuple(
    (degree, structure, regime)
    for regime in (False, True)
    for structure in ("two", "parity", "curvature")
    for degree in (1, 2, "clarke_glew")
)


def prepare(data: dict) -> tuple[dict, dict]:
    compounds = {item["compound_id"]: item for item in data["compounds"]}
    observations: dict[str, list[dict]] = {}
    for row in data["observations"]:
        observations.setdefault(row["compound_id"], []).append(row)
    return compounds, observations


def curve_weights(rows: list[dict], degree: int):
    """Reconcile independent sources using uncertainty and Birge inflation."""
    if len({row.get("literature_id") for row in rows}) < 2:
        return None
    scales = []
    for row in rows:
        uncertainty = row.get("expanded_uncertainty_kPa")
        confidence = row.get("confidence_level_percent")
        coverage = NormalDist().inv_cdf((1 + confidence / 100) / 2) if confidence and 0 < confidence < 100 else 1.
        scales.append(uncertainty / row["vapor_pressure_kPa"] / coverage if uncertainty and uncertainty > 0 else math.nan)
    reported = [scale for scale in scales if math.isfinite(scale)]
    if not reported:
        return None
    scales = np.array([scale if math.isfinite(scale) else float(np.median(reported)) for scale in scales])
    weights = 1 / scales
    sources = sorted({row.get("literature_id", "unreported") for row in rows})
    for source in sources:
        indices = [i for i, row in enumerate(rows) if row.get("literature_id", "unreported") == source]
        x = np.array([1 / rows[i]["temperature_K"] for i in indices])
        y = np.array([math.log(rows[i]["vapor_pressure_kPa"]) for i in indices])
        source_degree = min(degree, len(set(x)) - 1)
        if source_degree < 1:
            continue
        fitted = np.polynomial.Polynomial.fit(x, y, source_degree, w=weights[indices])
        reduced_chi_square = float(np.sum(((fitted(x) - y) / scales[indices]) ** 2) / max(1, len(indices) - source_degree - 1))
        # Saturation pressure should increase with temperature, hence decrease
        # with reciprocal temperature. Penalize inconsistent source curvature
        # smoothly rather than discarding measurements or changing uncertainties.
        inconsistent_fraction = float(np.mean(fitted.deriv()(x) >= 0))
        inflation = max(1., reduced_chi_square) * (1 + inconsistent_fraction)
        weights[indices] /= math.sqrt(inflation)
    return weights


def thermal_weights(rows: list[dict], treatment, policy: str = "oracle"):
    """Declare the three audit policies; production uses only oracle policy.

    No positive weight is floored or clipped. Clarke–Glew retains the existing
    three-coefficient quadratic proxy for source-consistency inflation.
    """
    if policy == "unweighted":
        return None
    if policy == "direct":
        return np.array([row["vapor_pressure_kPa"] / row["expanded_uncertainty_kPa"]
                         for row in rows], dtype=float)
    if policy != "oracle":
        raise ValueError(f"unknown weighting policy {policy}")
    return curve_weights(rows, 2 if treatment == "clarke_glew" else treatment)


def thermal_curve(rows: list[dict], treatment, policy: str = "oracle"):
    """Fit ln P with the declared weighting policy; evaluate at temperature."""
    temperatures = np.array([row["temperature_K"] for row in rows], dtype=float)
    parameters = 3 if treatment == "clarke_glew" else treatment + 1
    if len(set(temperatures)) < parameters:
        raise ValueError("insufficient distinct temperatures")
    y = np.log([row["vapor_pressure_kPa"] for row in rows])
    weights = thermal_weights(rows, treatment, policy)
    if treatment == "clarke_glew":
        reference_temperature = float(np.exp(np.mean(np.log(temperatures))))
        design = np.column_stack([
            np.ones(len(rows)), reference_temperature / temperatures - 1,
            np.log(temperatures / reference_temperature),
        ])
        w = np.ones(len(rows)) if weights is None else weights
        coefficients = np.linalg.lstsq(design * w[:, None], y * w, rcond=None)[0]

        def evaluate(temperature):
            basis = [1, reference_temperature / temperature - 1,
                     math.log(temperature / reference_temperature)]
            return float(np.array(basis) @ coefficients)

        return evaluate
    fitted = np.polynomial.Polynomial.fit(1 / temperatures, y, treatment, w=weights)
    return lambda temperature: float(fitted(1 / temperature))


def predictor(members: list[dict], observations: dict, candidate: tuple):
    degree, structure = candidate[:2]
    if len(candidate) == 3 and candidate[2]:
        estimates = []
        for phase in ("Crystal", "Liquid"):
            rows = {identity: [row for row in points if row.get("condensed_phase") == phase]
                    for identity, points in observations.items()}
            estimates.append(predictor(members, rows, candidate[:2]))

        def equilibrium(index: int, temperature: float) -> float:
            return min(estimate(index, temperature) for estimate in estimates)

        equilibrium.phase_estimates = estimates
        return equilibrium
    required = 2 if structure == "two" else 3
    if len(members) < required:
        raise ValueError("insufficient measured homologs")
    members = sorted(members, key=lambda item: item["homolog_index"])
    curves = {}
    for member in members:
        rows = observations[member["compound_id"]]
        curves[member["compound_id"]] = thermal_curve(rows, degree)

    def predict(index: int, temperature: float) -> float:
        chosen = members
        if structure in ("two", "curvature"):
            lower = [item for item in members if item["homolog_index"] < index]
            upper = [item for item in members if item["homolog_index"] > index]
            if structure == "two" and lower and upper:
                chosen = [lower[-1], upper[0]]
            else:
                chosen = sorted(
                    members, key=lambda item: (abs(item["homolog_index"] - index), item["homolog_index"])
                )[:required]
        x = np.array([item["homolog_index"] - index for item in chosen], dtype=float)
        y = np.array([curves[item["compound_id"]](temperature) for item in chosen])
        if structure == "parity":
            same = [item for item in chosen if item["homolog_index"] % 2 == index % 2]
            lower = [item for item in same if item["homolog_index"] < index]
            upper = [item for item in same if item["homolog_index"] > index]
            if lower and upper:
                a, b = lower[-1], upper[0]
                weight = (index - a["homolog_index"]) / (b["homolog_index"] - a["homolog_index"])
                return float((1 - weight) * curves[a["compound_id"]](temperature)
                             + weight * curves[b["compound_id"]](temperature))
            parity = np.array([item["homolog_index"] % 2 - index % 2 for item in chosen])
            design = np.column_stack([np.ones(len(x)), x, parity])
            if np.linalg.matrix_rank(design) < 3:
                raise ValueError("parity fit is not identifiable")
            return float(np.linalg.lstsq(design, y, rcond=None)[0][0])
        return float(np.polynomial.Polynomial.fit(x, y, required - 1)(0))

    return predict


def cross_validate(members: list[dict], observations: dict, candidate: tuple) -> list[dict]:
    folds = []
    for held in sorted(members, key=lambda item: item["homolog_index"]):
        remaining = [item for item in members if item != held]
        predict = predictor(remaining, observations, candidate)
        errors = [
            abs(predict(held["homolog_index"], row["temperature_K"]) - math.log(row["vapor_pressure_kPa"]))
            for row in observations[held["compound_id"]]
        ]
        folds.append({"compound_id": held["compound_id"], "homolog_index": held["homolog_index"],
                      "male": float(np.mean(errors)), "maximum": max(errors)})
    return folds


def temperature_extrapolation_errors(members: list[dict], observations: dict,
                                     treatment, policy: str = "oracle",
                                     separate_regimes: bool = False) -> list[dict]:
    """Hold out the lowest quarter of each measured temperature range.

    Separate-regime candidates perform this split within each physical regime.
    The withheld observations are never used to calculate fitting weights.
    """
    folds = []
    for member in sorted(members, key=lambda item: item["homolog_index"]):
        rows = observations[member["compound_id"]]
        phases = ("Crystal", "Liquid") if separate_regimes else (None,)
        errors = []
        splits = []
        for phase in phases:
            points = rows if phase is None else [row for row in rows if row.get("condensed_phase") == phase]
            if not points:
                raise ValueError("missing measured regime")
            minimum = min(row["temperature_K"] for row in points)
            maximum = max(row["temperature_K"] for row in points)
            cutoff = minimum + .25 * (maximum - minimum)
            training = [row for row in points if row["temperature_K"] >= cutoff]
            held = [row for row in points if row["temperature_K"] < cutoff]
            if not held:
                raise ValueError("no held-out temperature range")
            fitted = thermal_curve(training, treatment, policy)
            errors.extend(fitted(row["temperature_K"]) - math.log(row["vapor_pressure_kPa"])
                          for row in held)
            splits.append({"phase": phase, "cutoff_K": cutoff,
                           "training_count": len(training), "held_count": len(held),
                           "held_min_K": min(row["temperature_K"] for row in held),
                           "held_max_K": max(row["temperature_K"] for row in held)})
        folds.append({"compound_id": member["compound_id"], "homolog_index": member["homolog_index"],
                      "male": float(np.mean(np.abs(errors))), "signed_bias": float(np.mean(errors)),
                      "splits": splits})
    return folds


def select(members: list[dict], observations: dict) -> tuple[tuple, dict]:
    scores = {}
    extrapolation_scores = {}
    for candidate in CANDIDATES:
        try:
            folds = cross_validate(members, observations, candidate)
            compound_score = float(np.mean([fold["male"] for fold in folds]))
            thermal_key = (candidate[0], candidate[2])
            if thermal_key not in extrapolation_scores:
                temperature_folds = temperature_extrapolation_errors(
                    members, observations, candidate[0], separate_regimes=candidate[2])
                extrapolation_scores[thermal_key] = float(np.mean([fold["male"] for fold in temperature_folds]))
            score = (compound_score + extrapolation_scores[thermal_key]) / 2
            if math.isfinite(score):
                scores[candidate] = score
        except ValueError:
            continue
    # Two measured members cannot support a two-neighbor validation fold.
    # The first, least-complex candidate is the fixed sparse-data fallback.
    # Algebraically equivalent validation fits can differ by roundoff. Resolve
    # numerical ties by the fixed candidate order, never by a series identifier.
    best = min(scores.values()) if scores else math.inf
    chosen = next((candidate for candidate in CANDIDATES
                   if candidate in scores and scores[candidate] <= best + 1e-12), CANDIDATES[0])
    return chosen, {f"{candidate[0]}:{candidate[1]}:{'regime' if candidate[2] else 'single'}": score
                    for candidate, score in scores.items()}


def validation_errors(members: list[dict], observations: dict) -> list[dict]:
    """Nested validation: the held compound cannot participate in selection."""
    folds = []
    for held in sorted(members, key=lambda item: item["homolog_index"]):
        remaining = [item for item in members if item != held]
        candidate, scores = select(remaining, observations)
        predict = predictor(remaining, observations, candidate)
        errors = [abs(predict(held["homolog_index"], row["temperature_K"]) - math.log(row["vapor_pressure_kPa"]))
                  for row in observations[held["compound_id"]]]
        folds.append({"compound_id": held["compound_id"], "homolog_index": held["homolog_index"],
                      "candidate": list(candidate), "training_validation_male": scores,
                      "male": float(np.mean(errors)), "maximum": max(errors)})
    return folds


def regime_predictor(members: list[dict], observations: dict):
    """Infer a solid/liquid pressure crossover from separately fitted regimes."""
    estimates = []
    for phase in ("Crystal", "Liquid"):
        rows = {identity: [row for row in points if row.get("condensed_phase") == phase]
                for identity, points in observations.items()}
        candidate, _ = select(members, rows)
        estimates.append(predictor(members, rows, candidate))

    def predict(index: int, temperature: float) -> float:
        # The stable condensed phase has the lower chemical potential and
        # therefore the lower equilibrium pressure. The intersection determines
        # the inferred phase transition without a held compound's melting point.
        return min(estimate(index, temperature) for estimate in estimates)

    return predict


def solve(data: dict) -> tuple[dict, dict]:
    compounds, observations = prepare(data)
    estimators = {}
    selection = {}
    for series in data["series"]:
        sid = series["series_id"]
        members = [item for item in compounds.values() if item["series_id"] == sid and item["compound_id"] in observations]
        candidate, scores = select(members, observations)
        estimators[sid] = predictor(members, observations, candidate)
        selection[sid] = {"candidate": list(candidate), "validation_male": scores}
    predictions = []
    for target in data["targets"]:
        compound = compounds[target["compound_id"]]
        log_pressure = estimators[compound["series_id"]](compound["homolog_index"], target["temperature_K"])
        predictions.append({"target_id": target["target_id"], "vapor_pressure_kPa": math.exp(log_pressure)})
    return {"predictions": predictions}, selection


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(DATA) / "thermoml_vapor_pressure.json")
    parser.add_argument("--out", type=Path, default=Path(OUT))
    args = parser.parse_args()
    data = json.loads(args.data.read_text(encoding="utf-8"))
    result, selection = solve(data)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result) + "\n", encoding="utf-8")
    print(json.dumps(selection, sort_keys=True))


if __name__ == "__main__":
    main()
