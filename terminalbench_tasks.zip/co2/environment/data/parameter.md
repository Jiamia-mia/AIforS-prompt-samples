# Fixed parameters

## Constants and geometry

| Quantity | Symbol | Value | Unit |
|---|---|---:|---|
| Temperature | T | 298.15 | K |
| Gas constant | R | 8.314462618 | J/(mol K) |
| Faraday constant | F | 96485.33212 | C/mol |
| Film thickness | L | 1.0e-4 | m |
| Cathode area | A_el | 1.0e-4 | m2 |
| Electrolyte flow | Q | 1.0e-8 | m3/s |
| CO2 transfer coefficient | k_g | 1.0e-3 | m/s |
| Gas-equilibrium dissolved CO2 concentration, both scans | c_C_star | 34.2 | mol/m3 |
| Electrode concentration reference | c_ref | 34.2 | mol/m3 |
| Transfer coefficient | alpha | 0.5 | dimensionless |
| Electrons per CO | n | 2 | dimensionless |
| Effective potential reference | E_ref | 0.0 | V, prescribed model scale |
| Solute standard concentration | c_standard | 1000.0 | mol/m3 |
| Liquid water activity | a_H2O | 1.0 | dimensionless |
| Gas standard pressure | p_standard | 1.0e5 | Pa |

## Diffusion coefficients

| Species | Charge | D (m2/s) |
|---|---:|---:|
| CO2(aq) | 0 | 1.91e-9 |
| HCO3-(aq) | -1 | 1.19e-9 |
| CO3^2-(aq) | -2 | 9.23e-10 |
| OH-(aq) | -1 | 5.27e-9 |
| K+(aq) | +1 | 1.96e-9 |

## Free-species inlet concentrations

All concentrations are in mol/m3.

| Workbook sheet | CO2(aq) | OH- | HCO3- | CO3^2- | K+ |
|---|---:|---:|---:|---:|---:|
| KOH | 0 | 1000.0 | 0 | 0 | 1000.0 |
| Carbonate | 2.3273743636789186e-5 | 4.659756742835715 | 4.659756742835715 | 100.0 | 209.31951348567142 |

## Standard formation thermochemistry

Values are at 298.15 K and use the conventional aqueous H+ reference. Ideal solute activity is concentration divided by c_standard. Delta_f_S_standard denotes formation entropy.

| Species and phase | Delta_f_H_standard (kJ/mol) | Delta_f_S_standard (J/(mol K)) | Delta_f_G_standard (kJ/mol) |
|---|---:|---:|---:|
| H2O(l) | -285.83 | -163.307060 | -237.14 |
| CO(g) | -110.53 | +89.350998 | -137.17 |
| CO2(aq) | -413.80 | -93.241657 | -386.00 |
| OH-(aq) | -229.99 | -243.870535 | -157.28 |
| HCO3-(aq) | -691.99 | -352.641288 | -586.85 |
| CO3^2-(aq) | -677.14 | -500.553413 | -527.90 |

## Kinetic parameter units

| Parameter | Unit |
|---|---|
| k1f, k2f | m3/(mol s) |
| k1b, k2b | 1/s |
| j0 | A/m2 |
