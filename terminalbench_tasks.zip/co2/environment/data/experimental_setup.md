# Experimental setup

## Cell and measurements

The datasets contain steady-state virtual voltage scans in KOH and carbonate electrolytes. The cathode is at x=0; a well-mixed electrolyte compartment is at x=L. Fresh electrolyte enters and leaves this compartment at volumetric flow rate Q. Outlet concentrations refer to this compartment and are measured responses, not prescribed boundary concentrations.

The liquid film is stagnant, isothermal and ideal. Track dissolved CO2, OH-, HCO3-, CO3^2- and K+. Exclude hydrogen evolution and double-layer effects. Fluxes are positive toward increasing x. Concentrations use mol/m3, fluxes mol/(m2 s), and potentials V.

## Transport and homogeneous reactions

CO2 enters through the cathode side by finite-rate gas-liquid transfer. Its delivery flux is proportional to the difference between the gas-equilibrium dissolved concentration and the local cathode-side dissolved concentration, with proportionality coefficient k_g.

Dissolved CO2 undergoes Fickian diffusion. Ions undergo diffusion and electrical migration with ideal dilute-solution mobilities related to their diffusion coefficients by the Einstein relation. Maintain local electroneutrality and steady local species balances.

The first homogeneous reaction converts one dissolved CO2 and one OH- into one HCO3-. Its forward rate is proportional to both reactant concentrations, with coefficient k1f; its reverse rate is proportional to HCO3- concentration, with coefficient k1b.

The second reaction converts one HCO3- and one OH- into one CO3^2- and one water molecule. Its forward rate is proportional to both solute reactant concentrations, with coefficient k2f; its reverse rate is proportional to CO3^2- concentration, with coefficient k2b. Liquid water has unit activity. Both reactions retain finite forward and reverse rates. K+ is chemically inert.

## Cathode

Each CO molecule formed consumes one dissolved CO2 and transfers two electrons, releasing two OH- into the film. CO production accounts for all cathodic current.

Use the full Butler-Volmer relation, with positive cathodic current, transfer coefficient alpha, and electron number n. Its prefactor is j0 multiplied by the local dissolved CO2 concentration divided by c_ref. Overpotential is the recorded potential minus E_ref and the local solution potential. The solution potential at x=L is zero; recorded potentials use the effective reference scale in parameter.md.

The net cathode-side CO2 flux into the liquid is gas delivery minus electrochemical CO2 consumption. OH- enters the film at twice the CO production flux. HCO3-, CO3^2- and K+ have zero cathode flux.

## Electrolyte compartment

For every species, the film delivers material to the compartment, and electrolyte flow carries the difference between outlet and inlet concentrations away.

The compartment also includes paired-anode OH- consumption: one OH- is consumed per electron transferred through the external circuit. Include this sink in its steady OH- balance. No other compartment reactions are included.

## Reported quantities

Total current is cathode current density multiplied by cathode area. Convert current to CO production using two electrons per CO molecule. CO production rate is CO flux multiplied by cathode area.