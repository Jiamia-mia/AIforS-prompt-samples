#!/usr/bin/env bash
set -euo pipefail

# Fit log(k1f), log(k2f), log(j0) on a 2400-cell graded mesh with k1b=k1f/K1 and
# k2b=k2f/K2 from the Gibbs energies in parameter.md, then evaluate weighted_RMSE
# on a 4800-cell mesh and write /app/result.json.
python3 /solution/fit.py --input-dir /app --output /app/result.json --cells 2400 --start 2.0 2e4 0.5
