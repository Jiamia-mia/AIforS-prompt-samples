"""Author reference: read participant workbook + thermochemistry, fit, export parameters and weighted RMSE.

Never reads generation_metadata.json, public_data.json or golden_answer.json.
"""
import argparse, json, time
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from model import Film, Condition, DEFAULT_KNOWN, F, R, T
from xlsx_io import xlsx_records

CHAIN=np.array([[1,0,0],[1,0,0],[0,1,0],[0,1,0],[0,0,1]],float)
ROOT=Path(__file__).parent

def inputs(folder):
    parameter=(folder/'parameter.md').read_text().replace('−','-')
    def table_row(name, columns=None):
        matches=[[s.strip() for s in line.split('|')[1:-1]] for line in parameter.splitlines()
                 if line.startswith('| '+name+' |')]
        return next(row for row in matches if columns is None or len(row)==columns)
    G={s:float(table_row(s,4)[3])*1000 for s in ['H2O(l)','CO(g)','CO2(aq)','OH-(aq)','HCO3-(aq)','CO3^2-(aq)']}
    dG=np.array([G['HCO3-(aq)']-G['CO2(aq)']-G['OH-(aq)'],
                 G['CO3^2-(aq)']+G['H2O(l)']-G['HCO3-(aq)']-G['OH-(aq)']])
    K=np.exp(-dG/(R*T))/1000
    rows=[]
    for group in ['KOH','Carbonate']:
        c,o,b,a,p=map(float,table_row(group)[1:])
        assert abs(p-o-b-2*a)<1e-10
        for row in xlsx_records(folder/'electrolysis_experiments.xlsx',group):
            condition=Condition(o,34.2,row['E_V'],True,bicarbonate=b,carbonate=a,dissolved_co2=c)
            obs=np.array([row['OH_L_mol_m3'],row['HCO3_L_mol_m3'],row['CO3_L_mol_m3'],row['current_A']/1e-4])
            sigma=np.r_[np.maximum(.002*abs(obs[:3]),1e-5),max(.002*abs(obs[3]),1e-5)]
            rows.append(dict(id=row['id'],condition=condition,obs=obs,sigma=sigma))
    return rows,K

class Objective:
    def __init__(self,rows,K,cells):
        self.rows=rows;self.K=K;self.film=Film(cells);self.states=[None]*len(rows);self.previous=None
    def expanded(self,q):
        k1,k2,j0=np.exp(q)
        return np.array([k1,k1/self.K[0],k2,k2/self.K[1],j0])
    def evaluate(self,q):
        if self.previous is not None and np.array_equal(q,self.previous):return self.res,self.J
        theta=self.expanded(q);res=[];jac=[]
        for i,row in enumerate(self.rows):
            obs,deriv,state,diag=self.film.solve(row['condition'],theta,initial=self.states[i],sensitivity=True)
            self.states[i]=state
            res.extend((obs-row['obs'])/row['sigma'])
            jac.extend((deriv@CHAIN)/row['sigma'][:,None])
        self.previous=q.copy();self.res=np.array(res);self.J=np.array(jac)
        return self.res,self.J
    def fun(self,q):return self.evaluate(q)[0]
    def jac(self,q):return self.evaluate(q)[1]

def output(rows,theta,film,rmse):
    return dict(parameters={'k1f_m3_mol_s':float(theta[0]),'k1b_s_inv':float(theta[1]),
                           'k2f_m3_mol_s':float(theta[2]),'k2b_s_inv':float(theta[3]),'j0_A_m2':float(theta[4])},
                weighted_RMSE=float(rmse))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--input-dir',type=Path,default=Path('/app'))
    parser.add_argument('--output',type=Path,default=Path('/app/result.json'))
    parser.add_argument('--cells',type=int,default=2400)
    parser.add_argument('--start',type=float,nargs=3,default=[2.0,2e4,0.5])
    args=parser.parse_args();begin=time.perf_counter()
    rows,K=inputs(args.input_dir);obj=Objective(rows,K,args.cells)
    fit=least_squares(obj.fun,np.log(args.start),jac=obj.jac,
      bounds=np.log(([1e-3,1e2,1e-3],[1e3,1e8,1e2])),x_scale='jac',
      ftol=2e-10,xtol=2e-10,gtol=1e-8,max_nfev=60)
    theta=obj.expanded(fit.x)
    fine=Film(max(4800,args.cells))
    residuals=[]
    for row in rows:
        obs,_,_=fine.solve(row['condition'],theta)
        residuals.extend((obs-row['obs'])/row['sigma'])
    result=output(rows,theta,fine,np.sqrt(np.mean(np.array(residuals)**2)))
    args.output.write_text(json.dumps(result,indent=2))
    print(json.dumps(dict(parameters=result['parameters'],weighted_RMSE=result['weighted_RMSE'],
               evaluations=fit.nfev,success=bool(fit.success),seconds=time.perf_counter()-begin)),flush=True)

if __name__=='__main__':main()
