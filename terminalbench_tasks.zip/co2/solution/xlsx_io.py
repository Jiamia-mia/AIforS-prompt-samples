"""Minimal read-only XLSX reader used by the golden fitting script."""

from __future__ import annotations

import posixpath
import zipfile
import xml.etree.ElementTree as ET


def xlsx_records(path, sheetname):
    """Return worksheet rows as dictionaries without requiring Excel."""
    ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    relationship_id = (
        "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
    )
    with zipfile.ZipFile(path) as archive:
        strings = []
        if "xl/sharedStrings.xml" in archive.namelist():
            shared = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            strings = ["".join(item.itertext()) for item in shared]

        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        sheet_id = next(
            sheet.attrib[relationship_id]
            for sheet in workbook.findall("s:sheets/s:sheet", ns)
            if sheet.attrib["name"] == sheetname
        )
        relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        target = next(
            rel.attrib["Target"]
            for rel in relationships
            if rel.attrib["Id"] == sheet_id
        )
        target = (
            target.lstrip("/")
            if target.startswith("/")
            else posixpath.normpath("xl/" + target)
        )

        worksheet = ET.fromstring(archive.read(target))
        records = []
        for row in worksheet.findall("s:sheetData/s:row", ns):
            values = {}
            for cell in row:
                reference = cell.attrib["r"]
                column = "".join(char for char in reference if char.isalpha())
                kind = cell.attrib.get("t")
                value_node = cell.find("s:v", ns)
                if kind == "s":
                    value = strings[int(value_node.text)] if value_node is not None else ""
                elif kind == "inlineStr":
                    value = "".join(cell.find("s:is", ns).itertext())
                elif kind == "str":
                    value = value_node.text if value_node is not None else ""
                elif value_node is not None:
                    value = float(value_node.text)
                else:
                    continue
                values[column] = value
            records.append(values)

        headers = records[0]
        return [
            {headers[key]: value for key, value in row.items() if key in headers}
            for row in records[1:]
            if row.get("A")
        ]
