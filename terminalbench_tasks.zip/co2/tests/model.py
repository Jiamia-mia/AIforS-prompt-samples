"""Synthetic finite-film/CSTR inverse problem; SI units, ideal electroneutral NP."""
from dataclasses import dataclass,replace
import time
import numpy as np
from scipy.sparse import diags,bmat,lil_matrix
from scipy.sparse.linalg import splu

D=np.array([1.91e-9,1.19e-9,9.23e-10,5.27e-9,1.96e-9])
Z=np.array([0.,-1.,-2.,-1.,1.])
F=96485.33212;R=8.314462618;T=298.15
PARAM_NAMES=['k1f','k1b','k2f','k2b','j0']
DEFAULT_KNOWN=dict(L=1e-4,kg=1e-3,v=1e-4,area=1e-4,alpha=.5,n=2.,cref=34.2,Eeq=0.)
def mesh(cells):
    assert cells%2==0
    left=.5*DEFAULT_KNOWN['L']*np.expm1(7*np.linspace(0,1,cells//2+1))/np.expm1(7)
    return np.r_[left,DEFAULT_KNOWN['L']-left[-2::-1]]

@dataclass
class Condition:
    oh:float
    co2:float
    voltage:float=0.
    electro:bool=False
    bicarbonate:float=0.
    carbonate:float=0.
    dissolved_co2:float=0.

    def feed(self):
        return np.array([self.dissolved_co2,self.bicarbonate,self.carbonate,
                         self.oh,self.oh+self.bicarbonate+2*self.carbonate])

class Film:
    def __init__(self,cells=400,known=None,mesh_kind="graded"):
        self.known=DEFAULT_KNOWN.copy()
        if known:self.known.update(known)
        self.x=(mesh(cells)*self.known['L']/DEFAULT_KNOWN['L'] if mesh_kind=='graded' else np.linspace(0,self.known['L'],cells+1))
        self.n=len(self.x);self.h=np.diff(self.x/self.known['L'])
        self.scale=1000.;self.fs=D[0]*self.scale/self.known['L']
        self.dr=D/D[0]
        self.vol=np.r_[self.h[0]/2,(self.h[:-1]+self.h[1:])/2,self.h[-1]/2]
        self.weight=self.vol*self.known['L']/self.fs
        self.max_iter=60
    def current(self,u,cond,theta):
        if not cond.electro:return 0.,0.,0.
        # Prescribed concentration-dependent, symmetric-reference Butler-Volmer law.
        k=self.known
        a=-k['n']*(F*(cond.voltage-k['Eeq'])/(R*T)-u[5,0])
        cath=np.exp(k['alpha']*a);anod=np.exp(-(1-k['alpha'])*a)
        pref=theta[4]/(k['n']*F*k['cref'])
        co=pref*u[0,0]*self.scale*(cath-anod)
        dco_c=pref*self.scale*(cath-anod)
        dco_p=pref*u[0,0]*self.scale*k['n']*(k['alpha']*cath+(1-k['alpha'])*anod)
        return co,dco_c,dco_p
    def calc(self,u,cond,theta,jac=True,param=False):
        n=self.n;h=self.h;scale=self.scale;fs=self.fs;k=self.known
        c,b,a,o,p=u[:5]*scale
        r1=theta[0]*c*o-theta[1]*b;r2=theta[2]*b*o-theta[3]*a
        src=np.array([-r1,r1-r2,r2,-r1-r2,np.zeros(n)])
        dp=np.diff(u[5]);avg=(u[:5,1:]+u[:5,:-1])/2
        flux=-self.dr[:,None]*(np.diff(u[:5],axis=1)+Z[:,None]*avg*dp)/h
        co,dco_c,dco_p=self.current(u,cond,theta)
        gas=k['kg']*(cond.co2-c[0])
        qin=np.array([gas-co,0,0,2*co,0])/fs
        feed=cond.feed()
        qout=(k['v']*(u[:5,-1]*scale-feed)+np.array([0,0,0,2*co,0]))/fs
        res=np.zeros((6,n))
        res[:5,0]=flux[:,0]-qin
        res[:5,1:-1]=np.diff(flux,axis=1)
        res[:5,-1]=qout-flux[:,-1]
        res[:5]-=src*self.weight
        res[5]=Z@u[:5];res[5,-1]=u[5,-1]
        if not jac:return res.ravel()
        def edge_mat(left,right):
            diagonal=np.r_[left[0],left[1:]-right[:-1],-right[-1]]
            return diags([-left,diagonal,right],[-1,0,1],format='csc')
        d1=np.array([theta[0]*o,-theta[1]*np.ones(n),np.zeros(n),theta[0]*c,np.zeros(n)])*scale
        d2=np.array([np.zeros(n),theta[2]*o,-theta[3]*np.ones(n),theta[2]*b,np.zeros(n)])*scale
        ds=np.array([-d1,d1-d2,d2,-d1-d2,np.zeros((5,n))])
        blocks=[[None for _ in range(6)] for __ in range(6)]
        for i in range(5):
            for j in range(5):blocks[i][j]=-diags(ds[i,j]*self.weight,format='csc')
            left=self.dr[i]*(1-Z[i]*dp/2)/h
            right=-self.dr[i]*(1+Z[i]*dp/2)/h
            boundary=np.zeros(n);boundary[-1]=k['v']*scale/fs
            blocks[i][i]+=edge_mat(left,right)+diags(boundary)
            pl=self.dr[i]*Z[i]*avg[i]/h
            blocks[i][5]=edge_mat(pl,-pl)
            charge=np.full(n,Z[i]);charge[-1]=0
            blocks[5][i]=diags(charge,format='csc')
        gauge=np.zeros(n);gauge[-1]=1;blocks[5][5]=diags(gauge,format='csc')
        def add(i,j,row,col,value):
            m=lil_matrix((n,n));m[row,col]=value;blocks[i][j]+=m.tocsc()
        add(0,0,0,0,(k['kg']*scale+dco_c)/fs)
        add(0,5,0,0,dco_p/fs)
        for row,sgn in [(0,-1),(-1,1)]:
            add(3,0,row,0,sgn*2*dco_c/fs)
            add(3,5,row,0,sgn*2*dco_p/fs)
        J=bmat(blocks,format='csc')
        if not param:return res.ravel(),J
        dsdt=np.zeros((5,n,5))
        for j,dr in [(0,theta[0]*c*o),(1,-theta[1]*b)]:
            dsdt[0,:,j]=-dr;dsdt[1,:,j]=dr;dsdt[3,:,j]=-dr
        for j,dr in [(2,theta[2]*b*o),(3,-theta[3]*a)]:
            dsdt[1,:,j]=-dr;dsdt[2,:,j]=dr;dsdt[3,:,j]=-dr
        P=np.zeros((6,n,5));P[:5]=-dsdt*self.weight[None,:,None]
        P[0,0,4]+=co/fs;P[3,0,4]-=2*co/fs;P[3,-1,4]+=2*co/fs
        return res.ravel(),J,P.reshape(6*n,5)
    def _solve(self,cond,theta,initial=None,sensitivity=False):
        theta=np.asarray(theta)
        if initial is None:
            bulk=cond.feed()/self.scale
            u=np.vstack([np.tile(bulk[:,None],(1,self.n)),np.zeros(self.n)])
        else:u=np.array(initial,copy=True)
        start=time.perf_counter()
        for it in range(self.max_iter):
            res,J=self.calc(u,cond,theta)
            lu=splu(J);step=lu.solve(-res).reshape(6,self.n)
            merit=np.max(abs(step))
            # Newton correction, not raw stiff-reaction residual, governs stopping.
            if merit<2e-12:break
            damp=1.
            for _ in range(35):
                v=u+damp*step
                if np.min(v[:5])>=-1e-13:
                    trial_merit=np.max(abs(lu.solve(self.calc(v,cond,theta,False))))
                    if trial_merit<=(1-1e-4*damp)*merit:
                        u=v;break
                damp*=.5
            else:
                if merit<2e-10:break
                raise RuntimeError(f'Newton stagnation, correction={merit:.3g}, condition={cond}')
        else:raise RuntimeError('Newton iteration limit')
        c=u[:5]*self.scale;co,dc,dp=self.current(u,cond,theta)
        gas=self.known['kg']*(cond.co2-c[0,0])
        obs=np.r_[c[[3,1,2],-1],self.known['n']*F*co]
        qout=self.known['v']*(c[:,-1]-cond.feed())+[0,0,0,2*co,0]
        diagnostics=dict(iterations=it,correction=float(merit),raw_residual=float(np.max(abs(res))),
          solve_s=time.perf_counter()-start,charge_max_mol_m3=float(np.max(abs(Z@c))),
          CO_flux=co,gas_flux=gas,chemical_loss=float(gas-co-qout[0]),surface_CO2=float(c[0,0]),
          outlet_flux=qout.tolist(),phi0_V=float(u[5,0]*R*T/F))
        if sensitivity:
            res,J,P=self.calc(u,cond,theta,param=True)
            du=splu(J).solve(-P).reshape(6,self.n,5)
            dob=np.zeros((4,5));dob[:3]=du[[3,1,2],-1]*self.scale
            dco=dc*du[0,0]+dp*du[5,0];dco[4]+=co
            dob[3]=self.known['n']*F*dco
            return obs,dob,u,diagnostics
        return obs,u,diagnostics

    def solve(self,cond,theta,initial=None,sensitivity=False):
        try:
            return self._solve(cond,theta,initial,sensitivity)
        except RuntimeError as direct_error:
            def gas_start(parameters):
                fraction=.001
                stage=replace(cond,co2=cond.co2*fraction)
                _,state,_=self._solve(stage,parameters,None,False)
                # Resolve steep fronts with adaptive logarithmic continuation.
                attempts=0;growth=1.6
                while fraction<1.:
                    attempts+=1
                    if attempts>180:raise RuntimeError('Gas continuation limit')
                    target=min(1.,fraction*growth)
                    stage=replace(cond,co2=cond.co2*target)
                    try:
                        _,next_state,_=self._solve(stage,parameters,state,False)
                    except RuntimeError:
                        growth=np.sqrt(target/fraction)
                        if growth<1.0001:raise
                        continue
                    state=next_state;fraction=target;growth=min(1.6,growth*1.15)
                return state
            try:
                state=gas_start(theta)
            except RuntimeError:
                # Start the stiff second reaction slower, preserving its ratio;
                # then continue to the requested rates. No generator truth used.
                theta=np.asarray(theta);factor=min(1.,1e4/theta[2])
                if factor==1.:raise direct_error
                seed=theta.copy();seed[2:4]*=factor
                state=gas_start(seed)
                for f in np.geomspace(factor,1.,20)[1:]:
                    stage=theta.copy();stage[2:4]*=f
                    _,state,_=self._solve(cond,stage,state,False)
            return self._solve(cond,theta,state,sensitivity)
