#!/usr/bin/env python3
"""Grade fitted CO2-electrolyzer kinetic parameters by independent model recomputation."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from model import Condition, Film, F, R, T  # noqa: E402
from xlsx_io import xlsx_records  # noqa: E402

OUTPUT = Path("/app/result.json")
PARAMETER_MD = HERE / "parameter.md"
WORKBOOK = HERE / "electrolysis_experiments.xlsx"
PARAM_KEYS = ("k1f_m3_mol_s", "k1b_s_inv", "k2f_m3_mol_s", "k2b_s_inv", "j0_A_m2")
CELLS = 2400
AREA = 1e-4
CO2_STAR = 34.2
C_STANDARD = 1000.0
MAX_RMSE = 1.2
MAX_RMSE_MISMATCH = 0.01
MAX_RATIO_DEVIATION = 0.01
N_RESIDUALS = 96


def _is_number(value) -> bool:
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def _table_row(text: str, name: str, columns: int | None = None) -> list[str]:
    rows = [[cell.strip() for cell in line.split("|")[1:-1]] for line in text.splitlines()
            if line.startswith("| " + name + " |")]
    return next(row for row in rows if columns is None or len(row) == columns)


def equilibrium_constants() -> np.ndarray:
    text = PARAMETER_MD.read_text(encoding="utf-8").replace("−", "-")
    G = {s: float(_table_row(text, s, 4)[3]) * 1000
         for s in ("H2O(l)", "CO2(aq)", "OH-(aq)", "HCO3-(aq)", "CO3^2-(aq)")}
    dG = np.array([G["HCO3-(aq)"] - G["CO2(aq)"] - G["OH-(aq)"],
                   G["CO3^2-(aq)"] + G["H2O(l)"] - G["HCO3-(aq)"] - G["OH-(aq)"]])
    return np.exp(-dG / (R * T)) / C_STANDARD


def experiments() -> list[dict]:
    text = PARAMETER_MD.read_text(encoding="utf-8").replace("−", "-")
    rows = []
    for sheet in ("KOH", "Carbonate"):
        c, o, b, a, _ = map(float, _table_row(text, sheet)[1:])
        for record in xlsx_records(WORKBOOK, sheet):
            condition = Condition(o, CO2_STAR, record["E_V"], True,
                                  bicarbonate=b, carbonate=a, dissolved_co2=c)
            rows.append(dict(id=record["id"], condition=condition,
                             conc=np.array([record["OH_L_mol_m3"], record["HCO3_L_mol_m3"],
                                            record["CO3_L_mol_m3"]]),
                             current=float(record["current_A"])))
    return rows


def load_submission() -> tuple[dict, float]:
    assert OUTPUT.is_file(), f"missing {OUTPUT}"
    try:
        document = json.loads(OUTPUT.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        pytest.fail(f"invalid JSON in {OUTPUT}: {exc}")
    assert isinstance(document, dict), "top level must be a JSON object"
    assert set(document) == {"parameters", "weighted_RMSE"}, \
        f"top-level keys must be exactly parameters and weighted_RMSE, got {sorted(document)}"
    params = document["parameters"]
    assert isinstance(params, dict), "parameters must be an object"
    assert set(params) == set(PARAM_KEYS), f"parameter keys mismatch: {sorted(params)}"
    for key in PARAM_KEYS:
        assert _is_number(params[key]) and params[key] > 0, f"{key} must be a finite positive number"
    rmse = document["weighted_RMSE"]
    assert _is_number(rmse) and rmse >= 0, "weighted_RMSE must be a finite nonnegative number"
    return {key: float(params[key]) for key in PARAM_KEYS}, float(rmse)


def recompute_rmse(params: dict) -> float:
    theta = np.array([params[key] for key in PARAM_KEYS])
    film = Film(CELLS)
    residuals = []
    for row in experiments():
        try:
            film.max_iter = 60
            obs, _, _ = film.solve(row["condition"], theta)
        except (RuntimeError, ArithmeticError, ValueError):
            # Single retry with a larger Newton iteration budget; tolerances unchanged.
            film.max_iter = 600
            try:
                obs, _, _ = film.solve(row["condition"], theta)
            except (RuntimeError, ArithmeticError, ValueError) as exc:
                pytest.fail(f"model did not converge for {row['id']}: {exc}")
        obs = np.asarray(obs, dtype=float)
        if not np.all(np.isfinite(obs)):
            pytest.fail(f"nonfinite model prediction for {row['id']}")
        sigma_c = np.maximum(0.002 * np.abs(row["conc"]), 1e-5)
        current_pred = obs[3] * AREA
        sigma_i = max(0.002 * abs(row["current"]), 1e-9)
        residuals.extend((obs[:3] - row["conc"]) / sigma_c)
        residuals.append((current_pred - row["current"]) / sigma_i)
    residuals = np.array(residuals)
    assert residuals.size == N_RESIDUALS, f"expected {N_RESIDUALS} residuals, got {residuals.size}"
    assert np.all(np.isfinite(residuals)), "nonfinite residuals"
    return float(np.sqrt(np.sum(residuals ** 2) / N_RESIDUALS))


@pytest.fixture(scope="session")
def submission():
    return load_submission()


@pytest.fixture(scope="session")
def recomputed(submission):
    params, _ = submission
    return recompute_rmse(params)


def test_output_structure(submission):
    params, rmse = submission
    assert len(params) == 5 and rmse >= 0


def test_thermodynamic_consistency(submission):
    params, _ = submission
    K1, K2 = equilibrium_constants()
    ratio1 = params["k1f_m3_mol_s"] / params["k1b_s_inv"]
    ratio2 = params["k2f_m3_mol_s"] / params["k2b_s_inv"]
    assert abs(ratio1 / K1 - 1) <= MAX_RATIO_DEVIATION, f"k1f/k1b={ratio1:.6g}, K1={K1:.6g}"
    assert abs(ratio2 / K2 - 1) <= MAX_RATIO_DEVIATION, f"k2f/k2b={ratio2:.6g}, K2={K2:.6g}"


def test_reported_rmse_within_limit(submission):
    _, rmse = submission
    assert rmse <= MAX_RMSE, f"reported weighted_RMSE {rmse} exceeds {MAX_RMSE}"


def test_recomputed_rmse_within_limit(recomputed):
    print(f"recomputed weighted_RMSE={recomputed:.9f}")
    assert recomputed <= MAX_RMSE, f"recomputed weighted_RMSE {recomputed:.6f} exceeds {MAX_RMSE}"


def test_reported_rmse_matches_recomputed(submission, recomputed):
    _, rmse = submission
    assert abs(rmse - recomputed) <= MAX_RMSE_MISMATCH, \
        f"reported {rmse:.6f} vs recomputed {recomputed:.6f}"


@pytest.mark.parametrize("key", PARAM_KEYS)
def test_parameter_in_accepted_range(submission, key):
    params, _ = submission
    ranges = json.loads((HERE / "ref_values.json").read_text(encoding="utf-8"))["parameter_ranges"]
    low, high = ranges[key]
    assert low <= params[key] <= high, f"{key}={params[key]:.9g} outside [{low}, {high}]"
