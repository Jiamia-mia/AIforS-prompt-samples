# Exact count

The minimum width is $t=3$. There are $17{,}217{,}203{,}029{,}020$ full schedules of that width, giving **995** modulo 1001.

## Why a partition is enough

For disjoint current bags $X,Y$, examine the original edge incidences in $X\times Y$. Their relation is black when every incidence is an edge, absent when none are edges, and red when both kinds occur. This holds at the singleton start. Merging two bags concatenates their incidence sets against each untouched bag. The union is all edges exactly when both sets are all edges, and it is all nonedges exactly when both sets are all nonedges. Every other case is mixed. Induction proves the rule and makes the current red degrees functions of the current partition alone.

## Counting labeled schedules

Read the 30 segments from the graph. The checked edge list is in [graph-edges.txt](graph-edges.txt). For each threshold $k$, give the singleton partition count 1. Process one layer of partitions at a time in decreasing order of bag count. For each partition $P$ and each unordered pair of distinct bags of $P$, form the successor $Q$. Add the count of $P$ to the count of $Q$ exactly when every red degree of $Q$ is at most $k$. Two prefixes reaching the same partition are both included in its count. The unordered-pair loop counts each choice once and retains the order of the successive choices. A partition with $k+1$ bags permits every remaining contraction because the red degree can never exceed the number of other bags. Consequently each such prefix contributes \(\prod_{\ell=2}^{k+1}\binom{\ell}{2}\) full schedules.

For a direct implementation, precompute the union $U_X$ and intersection $I_X$ of original neighbor sets of vertices in each possible bag $X$. The relation from $X$ to $Y$ is red exactly when $U_X\cap Y\ne\varnothing$ and $I_X\cap Y\ne Y$. The independent forward count gives the following checkpoints. A prefix is a particular sequence of contractions from the singleton partition.

| Bags remaining | Partitions at width at most 2 | Prefixes at width at most 2 | Partitions at width at most 3 | Prefixes at width at most 3 |
|---:|---:|---:|---:|---:|
| 16 | 1 | 1 | 1 | 1 |
| 15 | 10 | 10 | 24 | 24 |
| 14 | 36 | 73 | 226 | 451 |
| 13 | 58 | 369 | 1,103 | 6,558 |
| 12 | 42 | 1,176 | 3,169 | 73,708 |
| 11 | 12 | 1,980 | 6,203 | 656,343 |
| 10 | 1 | 1,080 | 10,412 | 4,908,413 |
| 9 | 0 | 0 | 18,238 | 33,563,237 |
| 8 | 0 | 0 | 33,856 | 226,793,933 |
| 7 | 0 | 0 | 64,328 | 1,581,820,357 |
| 6 | 0 | 0 | 133,549 | 11,622,711,568 |
| 5 | 0 | 0 | 339,127 | 95,651,127,939 |
| 4 | 0 | 0 | 1,140,908 | 956,511,279,390 |

At width 2 the layer of nine bags is already empty. At width 3 the nonempty layer of four bags guarantees completion. Thus $t=3$. At four bags there are \(\binom42\binom32\binom22=18\) tails per prefix. Therefore
\[
 A=956{,}511{,}279{,}390\cdot18
  =17{,}217{,}203{,}029{,}020
  =1001\cdot17{,}200{,}003{,}025+995.
\]

The [forward program](verify-count-forward.cpp) implements the partition recurrence with original adjacencies. The [backward program](verify-count.cpp) independently propagates red and black trigraph relations and memoizes suffix counts. Both return zero full schedules under threshold 2 and the same exact count under threshold 3.
