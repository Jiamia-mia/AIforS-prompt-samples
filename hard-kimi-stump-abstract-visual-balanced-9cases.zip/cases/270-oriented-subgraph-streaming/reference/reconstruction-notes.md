# 第 270 行重建说明

原题来自 Paper Bank!G270，使用无 BOM 的 UTF-8 导出，共 1,049 字节。由 XLSX 的共享字符串和 read-only openpyxl 两条路径交叉核对，SHA-256 为 `55c1994c79a15d645b72ade80621e25d8248a8796d8a8e13d93d141d79ab6015`。

论文为 Shih、Tsai、Tsai 和 Wu 的 *Space Complexity Dichotomies for Subgraph Finding Problems in the Streaming Model*，arXiv:2602.08002v1。PDF 第 1 页概括有向非诱导子图的判据，第 6 页定理 7 给出二分模式的单遍上下界，第 6 节证明并使用含混合顶点的路径和环。论文图 4–6 是归约示意。TeX 源包提供正文和制图资源，官方清单确认没有独立 SI。原图归属无法确认，本题图是按原题和论文判据构造的数学实例。

原题将图作为唯一拓扑来源。最终图片有 12 个具名圆圈、17 条有向弧，显示一个二分网格的具体定向。保留字母、圆圈与箭头本身，三条横行等距且无交叉。全部顶点和弧可从图中读出，三行递增字母可用于复核。求解使用相同的单遍、仅插入、随机、有向、非诱导子图模型。图外的数学定理只用于推导，实例无外部数据依赖。

对照构造也有 12 个顶点且最优值为 4，但其下界可以按两组不相交顶点分别证明至少删 2 个。采用的定向没有这种加性二分，三个横向路径只能先给出下界 3，剩余候选还需结合跨行的双混合顶点路径和带混合顶点的环排除。最优保留图同时展示容许的 well-oriented 环和单混合顶点树。按最短有效解法评为 `high`。完整上下界和独立穷举均得 4。

基线输入为原文和 `input/H.png`。标准答案是精确整数。

论文原图候选中，图 5（PDF 第 34 页）左侧的有限模式 H 可独立取出。按 TeX 源包中的 NWOTCC.pdf 对照箭头，模式 H 连通并有两个混合顶点。删去图中标为 v 的公共汇点后，两者同时失去出弧，所有余边均从源点指向汇点。因此该候选的删除数为 1，且题面没有把遗失图片锚定到图 5。重建图保留同一数学模型，并提供更难的删除实例。

## Kimi 基线

三次请求的题面和图片均与本目录基线输入逐字节一致。API 实际返回的模型均为 Kimi K3.1 Pro。下列运行均以 `length` 结束，所有生成 token 均用于推理，没有返回最终答复。独立核验记录均为 `incomplete`。

| 档位 | 输出上限 | 运行轨迹 |
| --- | ---: | --- |
| max | 24,576 | [轨迹](C:/Users/jtian/Desktop/Deepvault/recovery/dsh-test/results/20261122T160158-135996Z-RaUEyQ/270-oriented-subgraph-streaming/transcript.md) |
| high | 24,576 | [轨迹](C:/Users/jtian/Desktop/Deepvault/recovery/dsh-test/results/20261122T160850-284170Z-RCKtnA/270-oriented-subgraph-streaming/transcript.md) |
| high | 32,768 | [轨迹](C:/Users/jtian/Desktop/Deepvault/recovery/dsh-test/results/20261122T161520-606714Z-NuGNQQ/270-oriented-subgraph-streaming/transcript.md) |

L 留空。基线未获得完整可评分答复，提难复测未触发，M 留空。

