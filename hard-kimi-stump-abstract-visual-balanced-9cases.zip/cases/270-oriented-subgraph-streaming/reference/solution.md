# Solution

\(\boxed{\delta(H)=4}\).

A vertex is **mixed** if it has both an incoming and an outgoing arc in the remaining pattern. Use the one-pass oriented-subgraph dichotomy in the stated \(2/3\)-success model. A fixed pattern has \(n^{2-\Omega(1)}\) space complexity precisely when each weak component has zero mixed vertices, or is a tree with at most one mixed vertex. With zero mixed vertices, all arcs go from sources to sinks, giving the required well-oriented bipartition. A component with two mixed vertices, or one with a cycle and a mixed vertex, gives the quadratic lower bound. The bipartite-grid instances here are within Theorem 7 and the well-oriented upper bound in Corollary 11 of Shih, Tsai, Tsai and Wu, arXiv:2602.08002v1.

## Four deletions suffice

Delete \(A,B,G,K\). The two remaining weak components are:

- \(\{C,D,H,L\}\), with arcs \(D\to C,\ D\to H,\ H\to L\). This is a tree, and \(H\) is its only mixed vertex.
- \(\{E,F,I,J\}\), with arcs \(E\to F,\ E\to I,\ J\to F,\ J\to I\). This is a well-oriented four-cycle, with sources \(E,J\) and sinks \(F,I\).

Both components meet the dichotomy.

## Three deletions cannot suffice

Each row in the table is an obstruction in the printed graph. The arcs in the last column certify the stated obstruction. If no vertex in its set is deleted, those arcs survive, the indicated vertices stay mixed, and the same weak component still contains either two mixed vertices or a mixed vertex and a cycle. Therefore every feasible deletion set hits every row.

| Set | Mixed vertices | Surviving arcs |
| --- | --- | --- |
| \(ABCD\) | \(B,C\) | \(D\to C\to B\to A\) |
| \(EFGH\) | \(F,G\) | \(E\to F\to G\to H\) |
| \(IJKL\) | \(J,K\) | \(L\to K\to J\to I\) |
| \(ABEI\) | \(A,E\) | \(B\to A\to E\to I\) |
| \(DHKL\) | \(H,L\) | \(D\to H\to L\to K\) |
| \(ABFJ\) | \(B,F\) | \(J\to F\to B\to A\) |
| \(BCDEF\) | \(C,F\) | \(D\to C\to B\leftarrow F\leftarrow E\) |
| \(BCGHL\) | \(C,H\) | \(B\leftarrow C\leftarrow G\to H\to L\) |
| \(AEFIJ\) | \(E\) | Cycle \(E-F-J-I-E\), with \(A\to E\to F\) |
| \(CDGHJK\) | \(K\) | Cycle \(C-D-H-G-C\), with \(G\to K\to J\) |
| \(AEFG\) | \(E,F\) | \(A\to E\to F\to G\) |
| \(CDGHL\) | \(H\) | Cycle \(C-D-H-G-C\), with \(D\to H\to L\) |

The first three sets partition the vertices. A deletion set of size at most three must choose exactly one letter from each row. Write the resulting triple in top, middle, bottom order. The following counts come from intersecting its three-letter set with each additional row and retaining the triple exactly when the intersection is nonempty.

| Additional obstruction applied, cumulatively | With \(A\) | With \(B\) | With \(C\) | With \(D\) |
| --- | ---: | ---: | ---: | ---: |
| None | 16 | 16 | 16 | 16 |
| \(ABEI\) | 16 | 16 | 7 | 7 |
| \(DHKL\) | 10 | 10 | 3 | 7 |
| \(ABFJ\) | 10 | 10 | 0 | 2 |
| \(BCDEF\) | 4 | 10 | 0 | 2 |
| \(BCGHL\) | 2 | 10 | 0 | 0 |
| \(AEFIJ\) | 2 | 6 | 0 | 0 |
| \(CDGHJK\) | 0 | 4 | 0 | 0 |
| \(AEFG\) | 0 | 2 | 0 | 0 |
| \(CDGHL\) | 0 | 0 | 0 | 0 |

For example, after applying \(CDGHJK\) only \(BEK,BFK,BHI,BHJ\) remain. The set \(AEFG\) eliminates the two triples with \(H\), and \(CDGHL\) eliminates the two triples with \(K\). Thus a fourth deletion is necessary.

## Transcription and independent check

The full arc list is \(B\to A\), \(A\to E\), \(C\to B\), \(F\to B\), \(D\to C\), \(G\to C\), \(D\to H\), \(E\to F\), \(E\to I\), \(F\to G\), \(J\to F\), \(G\to H\), \(G\to K\), \(H\to L\), \(J\to I\), \(K\to J\), \(L\to K\). Independent enumeration of induced remainders checked the weak components and recomputed each vertex's in- and out-degree after deletion. The numbers of qualifying sets of sizes 0, 1, 2, 3 and 4 are respectively 0, 0, 0, 0, 27.
