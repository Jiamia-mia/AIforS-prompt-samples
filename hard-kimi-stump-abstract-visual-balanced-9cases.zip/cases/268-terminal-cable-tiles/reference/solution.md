# Minimum cable-tile pairing cost

The minimum cost is **26**.

## Tile costs from the stated rules

For a tile, set $n=\min(r,s)$ and $m=\max(r,s)$. Use the long direction as the column direction. An initially empty boundary column never receives contamination. For each of its cells, every admissible pair has at least one member within that column or beyond the boundary. Two initially empty consecutive columns also stay empty: every admissible pair that could contaminate a cell in that band has a member in the band. These claims follow by considering the first contamination in the boundary column or band.

Thus the first and last columns need seeds and there can never be consecutive unseeded columns. This requires at least $\lfloor m/2\rfloor+1$ seeds, counting the case $m=1$ as one column.

For $n=2$ and $m=2k+1$, attaining this bound with $k+1$ seeds would require exactly one seed in each odd column and none in the even columns. Diagonal rules and the opposite pair across the two rows are unavailable. The only new contaminated cells would be in an even column whose two neighboring seeds are in the same row. After adding those cells, each odd column still has no contaminated horizontal neighbor in the row opposite its seed. An even column with no contamination has one contaminated horizontal neighbor in each row, and an even column with one contaminated cell has both its horizontal neighbors in that cell's row. The configuration is closed under the rules. It never fills both rows, so this case requires at least $\lfloor m/2\rfloor+2$ seeds.

Use these lower bounds for every candidate. The seeds below attain the bounds on the tiles in the winning pairing.

## Enumerating eligible rectangles

Label terminals $B_i$ and $G_i$ in top-to-bottom order within each color. Coordinates are (row, column).

| $i$ | Black $B_i$ | Gray $G_i$ |
|---:|---|---|
| 1 | (1,8) | (1,5) |
| 2 | (3,4) | (3,7) |
| 3 | (4,9) | (4,2) |
| 4 | (5,2) | (6,2) |
| 5 | (5,6) | (6,10) |
| 6 | (7,3) | (8,3) |
| 7 | (8,2) | (9,5) |
| 8 | (9,9) | (9,10) |

The four absent lattice edges join $(2,2)$ and $(2,3)$, $(4,2)$ and $(5,2)$, $(5,6)$ and $(6,6)$, and $(6,1)$ and $(7,1)$. Each edge that is present joins consecutive sites on one axis. A tile must therefore use all the sites and lattice edges in a contiguous rectangular box. For a proposed terminal pair, the pair's bounding rectangle must avoid all other terminals and contain no absent edge. A failed bounding rectangle cannot be repaired by expansion. If it passes, check all its containing rectangles for the same conditions. Both expansion and testing use the displayed lattice, including the boundary.

For each pair, the table gives the smallest rule-based lower bound over its eligible rectangles. A dash means no eligible rectangle.

| | $G_1$ | $G_2$ | $G_3$ | $G_4$ | $G_5$ | $G_6$ | $G_7$ | $G_8$ |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| $B_1$ | 3 | 2 | - | - | - | - | - | - |
| $B_2$ | 2 | 3 | 3 | - | - | - | 5 | - |
| $B_3$ | - | 2 | 5 | - | 2 | - | - | - |
| $B_4$ | - | - | - | 2 | - | - | - | - |
| $B_5$ | 4 | 2 | - | - | - | - | - | - |
| $B_6$ | - | - | - | 2 | 5 | 2 | - | - |
| $B_7$ | - | - | - | 2 | - | 2 | - | - |
| $B_8$ | - | - | - | - | - | - | 3 | 2 |

One way to reproduce the table is to enumerate $1\le a\le b\le 9$ and $1\le c\le d\le 10$. In the box $[a,b]\times[c,d]$, discard the box if both endpoints of any of the four missing edges are inside it, or if the box contains anything other than one black and one gray terminal. For each remaining box, update the bound for its two terminals with the smaller value of the current bound and $\lfloor m/2\rfloor+1+\mathbf{1}[n=2\ \text{and}\ m\text{ odd}]$. This checks all 248 eligible rectangles.

For example, $B_5G_2$ has a $3\times2$ bounding rectangle with lower bound 3. Rows 3-5 and columns 5-7 give a $3\times3$ tile with bound 2. The $7\times2$ bounding rectangle for $B_2G_7$ has bound 5. Either extra adjacent column would introduce another terminal. Keeping width two and adding a row still gives a bound of at least 5.

## Global lower bound

$B_4$ must use $G_4$, so $B_7$ must use $G_6$. Then $B_6$ must use $G_5$. Only $B_8$ can use $G_8$, so $G_7$ must use $B_2$ and $G_3$ must use $B_3$. The lower bounds for these six pairs sum to $2+2+5+2+5+5=21$. The remaining two pairs use blacks $B_1,B_5$ and grays $G_1,G_2$. Their two possible totals are $3+2=5$ and $2+4=6$. Every pairing therefore costs at least 26.

## Pairing that attains 26

Use the following rectangles. Seed coordinates are local to each rectangle, starting at $(1,1)$ in its top-left corner. The last column records how many additional vertices are contaminated in each simultaneous round of the stated process.

| Pair | Rows | Columns | Seeds | Local seed coordinates | New vertices per round |
|---|---|---|---:|---|---|
| $B_1G_1$ | 1-1 | 5-8 | 3 | (1,1), (1,3), (1,4) | 1 |
| $B_2G_7$ | 3-9 | 4-5 | 5 | (1,1), (1,2), (3,1), (5,1), (7,1) | 3, 1, 1, 1, 1, 1, 1 |
| $B_3G_3$ | 4-4 | 2-9 | 5 | (1,1), (1,3), (1,5), (1,7), (1,8) | 3 |
| $B_4G_4$ | 5-6 | 2-2 | 2 | (1,1), (2,1) | All seeded |
| $B_5G_2$ | 3-5 | 5-7 | 2 | (1,1), (3,3) | 1, 4, 2 |
| $B_6G_5$ | 6-7 | 3-10 | 5 | (1,1), (1,3), (1,5), (1,7), (2,8) | 5, 1, 1, 1, 1, 1, 1 |
| $B_7G_6$ | 8-8 | 2-3 | 2 | (1,1), (1,2) | All seeded |
| $B_8G_8$ | 9-9 | 9-10 | 2 | (1,1), (1,2) | All seeded |

The rectangles cover each terminal once and any overlaps contain ordinary vertices only. In each row of the table the seeds plus all the newly contaminated vertices fill the rectangle. These seeds bound the sum of the tile costs above by $3+5+5+2+2+5+2+2=26$, so the lower bound is attained.

The rule model agrees with Figure 2 of the archived arXiv v3 paper. Theorem 1 gives the same dimension-dependent formula underlying the lower bounds. The argument above derives the needed bounds and demonstrates attainability directly from the exercise.
