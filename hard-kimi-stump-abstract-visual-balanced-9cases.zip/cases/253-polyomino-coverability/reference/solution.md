# Solution

The sum is **2456**.

## Classifying a connected remainder

A cover of a stain also covers any subset of that stain. Conversely, a sticker that fails to cover a subset fails to cover every stain containing it. These implications also hold when containment allows rotation and reflection, because the copies can undergo the same rigid transformation.

Use the finite polyomino classification of Oka, Inaba and Iino, arXiv:2602.19525v1, Section 3 and Figure 3. Theorem 3.9 gives the six always-coverable templates in the set $J$ of the paper. Any connected remainder that embeds in one of those templates is always-coverable. Theorem 3.4 gives the counterexample templates in the paper's set $I$. If a remainder contains one of these, it fails always-coverability. Appendix A supplies the positive proofs not already in Section 3.2. Appendix B gives the stickers for the negative templates. These results use translations, quarter-turns, reflections and coverage that may extend outside the stain, as in the question. Here every connected set encountered has an explicit match in one of the two directions.

## Counting deletions

Read the filled cells in each panel as an integer-coordinate set. Test the full set, then remove each cell in turn and each unordered pair in turn from the original set. Use edge connectivity before testing coverage. Count deletion subsets individually even when they give congruent remainders. For example, in panel C there are 14 connected remainders from two-cell deletions. Four fit a positive template, giving $r_2=4$.

| Panel | Cells | $b$ | $r_1$ | $r_2$ | $s_i$ | $i s_i$ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| A | 7 | 0 | 1 | 8 | 18 | 18 |
| B | 6 | 1 | 2 | 3 | 123 | 246 |
| C | 8 | 0 | 0 | 4 | 4 | 12 |
| D | 6 | 0 | 4 | 9 | 49 | 196 |
| E | 7 | 0 | 2 | 6 | 26 | 130 |
| F | 5 | 0 | 2 | 3 | 23 | 138 |
| G | 6 | 1 | 4 | 7 | 147 | 1029 |
| H | 7 | 0 | 1 | 10 | 20 | 160 |
| I | 8 | 0 | 0 | 3 | 3 | 27 |
| J | 6 | 0 | 4 | 10 | 50 | 500 |

For a check on the enumeration, each triple gives the counts of always-coverable connected, other connected, and disconnected remainders, respectively.

| Panel | One deletion | Two deletions |
| --- | ---: | ---: |
| A | 1 / 4 / 2 | 8 / 2 / 11 |
| B | 2 / 0 / 4 | 3 / 0 / 12 |
| C | 0 / 6 / 2 | 4 / 10 / 14 |
| D | 4 / 1 / 1 | 9 / 0 / 6 |
| E | 2 / 2 / 3 | 6 / 1 / 14 |
| F | 2 / 0 / 3 | 3 / 0 / 7 |
| G | 4 / 0 / 2 | 7 / 0 / 8 |
| H | 1 / 5 / 1 | 10 / 2 / 9 |
| I | 0 / 5 / 3 | 3 / 7 / 18 |
| J | 4 / 2 / 0 | 10 / 0 / 5 |

The final sum is $18+246+12+196+130+138+1029+160+27+500=2456$.

## Exact enumeration

The following Python uses only the transcribed blue cells and fixed mathematical templates. Each slash starts the next row in the drawing. The template orientation can be arbitrary because containment uses all eight grid symmetries. The two classification checks give opposite results for every connected set processed.

```python
from itertools import combinations

panels = {
    "A": ".#./###/##./#..",
    "B": "...#/..##/###.",
    "C": "####./.####",
    "D": ".#./###/##.",
    "E": ".##/##./##./#..",
    "F": ".##/.#./##.",
    "G": ".###/###.",
    "H": "#./##/##/##",
    "I": ".####/###../.#...",
    "J": "##/##/##",
}
positive_templates = (
    "#../###/.#.",  # 5/F
    "#../###/#..",  # 5/T
    "#./##/#./#.",  # 5/Y
    "#../#../##./.##",  # 6/3
    "#./#./#./##/.#",  # 6/N
    "#./##/##/.#",  # 6/S
)
negative_templates = (
    "#/#/#/#/#",  # 5/I
    "##/#./##",  # 5/U
    "###/#../#..",  # 5/V
    ".#./###/.#.",  # 5/X
    "#../###/..#",  # 5/Z
    "#./#./##/.#/.#",  # 6/5
    ".#./##./.##/.#.",  # 6/8
    "#../###/.#./.#.",  # 6/9
    "#../##./.##/.#.",  # 6/B
    "##/#./#./##",  # 6/C
    "#./##/##/#.",  # 6/D
    "#.../####/.#..",  # 6/F
    "##/##/#./#.",  # 6/P
    "##./###/#..",  # 6/R
    "#.../####/#...",  # 6/T
    "#../##./.##/..#",  # 6/W
    "#.../####/...#",  # 6/Z
    "#.../#.../##../.###",  # 7/1110_0011_0001_0001
)

def cells(rows):
    return {
        (x, y)
        for y, row in enumerate(rows.split("/"))
        for x, symbol in enumerate(row)
        if symbol == "#"
    }

def connected(shape):
    if not shape:
        return False
    first = next(iter(shape))
    reached, frontier = {first}, [first]
    while frontier:
        x, y = frontier.pop()
        for neighbor in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if neighbor in shape and neighbor not in reached:
                reached.add(neighbor)
                frontier.append(neighbor)
    return reached == shape

def orientations(shape):
    oriented = list(shape)
    for _ in range(4):
        yield oriented
        yield [(-x, y) for x, y in oriented]
        oriented = [(-y, x) for x, y in oriented]

def embeds(shape, container):
    if len(shape) > len(container):
        return False
    for transformed in orientations(shape):
        anchor_x, anchor_y = transformed[0]
        for x, y in container:
            dx, dy = x - anchor_x, y - anchor_y
            if all((a + dx, b + dy) in container for a, b in transformed):
                return True
    return False

positive = [cells(template) for template in positive_templates]
negative = [cells(template) for template in negative_templates]

def always_coverable(shape):
    if not connected(shape):
        return False
    fits_positive = any(embeds(shape, template) for template in positive)
    has_obstruction = any(embeds(template, shape) for template in negative)
    assert fits_positive != has_obstruction
    return fits_positive

total = 0
for index, (label, pattern) in enumerate(panels.items(), 1):
    stain = cells(pattern)
    b = int(always_coverable(stain))
    r1, r2 = (
        sum(always_coverable(stain - set(deletion))
            for deletion in combinations(stain, k))
        for k in (1, 2)
    )
    score = 100 * b + 10 * r1 + r2
    print(label, b, r1, r2, score, index * score)
    total += index * score

print(total)
```
