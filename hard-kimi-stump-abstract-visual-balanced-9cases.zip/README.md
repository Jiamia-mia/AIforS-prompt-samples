# DeepVault — Hard abstract-visual STEM benchmark sample

## 样本简介

本包包含 9 道已经重建、验收通过并实际测试的高难度题（原 XLSX 行号作为 ID）。每题的最终采用输入均在 **Kimi-K3.1-Pro + DSH + Scientific Agent tools** 测试中取得完整回答，经过独立 GPT-6.1 Sol High 核验为 `N`（错误，即 stump）。这不是 API 超时或截断造成的失败样本。题干与测试时的图像保持逐字节不变。

学科抽样覆盖数学、理论计算机科学、机器学习、量子信息相关图结构、有机化学和应用物理。没有把纯表格、矩阵、公式截图当作视觉任务。部分结构图带有必要的标签和测量参数，但至少有需要从图中理解的连边、空间几何或分子结构。

## 目录说明与使用方式

```text
README.md                      本文档
manifest.json                  所有题目的 ID、学科、难度、末次评测版本及输入哈希
SHA256SUMS                     包内所有文件的 SHA-256 校验值（不含自身）
cases/
  <xlsx-row>-<task-name>/
    input/                     唯一应交给被测模型的目录
      prompt.txt               原 prompt，UTF-8，未修改
      *.png                    原始输入图片；与实际送测文件一致
    reference/                 仅用于人工复核和独立核验，不送给被测模型
      golden_answer.txt        标准答案
      solution.md              参考解答与推理步骤
      reconstruction-notes.md 重建、选图及来源记录（若现有文件提供）
      sources/                 已保存的论文正文、所选支持信息和来源记录
    evaluation/                已完成盲测的不可变原始归档，不送给被测模型
      input/                   那次测试输入的原样备份
      requests/                实际送到 SwissAI 的模型请求
      responses/               实际 API SSE 响应，含供应商返回的推理和文本
      harness-requests/        DSH 本地请求（含供运行器过滤的本地上下文）
      trajectory.jsonl         时间顺序的模型、tool、ACP 交互事件
      mcp-audit.jsonl          MCP 工具调用参数及真实返回
      transcript.md            可读测试会话与工具轨迹
      toolkit-schema.json      当次测试暴露的工具名称和参数 schema
      resolved-profile.yml     当次 DSH 最终配置
      trajectory-summary.json  交互摘要
      dsh-log.txt              DSH runtime 日志
      result.json              实际最终回答、模型、参数、工具次数和完成状态
      verification.json        独立核验结论（N 表示回答错误）及完整性证书
      verifications/            核验请求的证据、结论和 token 统计
      manifest.json            那次评测的原始归档哈希清单
```

盲测新模型时，只读取 `cases/<task>/input/prompt.txt` 和该目录的所有图片，把 prompt 作为用户文本、图作为对应的多模态附件。不要附带 `reference/`、`evaluation/` 或包根目录的 manifest。不要把图片改写成公式或表格重新输入。测试结束后，再用 `reference/` 独立复核答案。`evaluation/` 保留的是原评测轨迹，用于复现、分析错误和比较，不是新测试的输入。验证证书的 `grade=N` 是不正确判定，不代表模型没有输出。若 API 没有返回内部推理，归档不会虚构该内容。

来源目录为了样本复核而选取已归档的正文与相关支持信息，并非整套文献下载镜像。例如有机化学第 35 行保留正文及实际用于核对的发表版 SI，不重复打包同一研究的较大预印本 SI。原工作目录未改变。

## Evaluation 方法

- **基础模型：** Swiss AI Research Platform 的 `RCP-AIaaS/moonshotai/Kimi-K3.1-Pro`。这是支持图像输入和多轮工具调用的 Kimi 基础推理模型，而不是 GPT 求解。
- **Agent 系统：** DSH（ACP 客户端/运行器）+ 本地 Scientific Agent MCP server。DSH 负责会话和工具循环；Kimi 解析图文输入、决定是否调用工具、整合工具输出并给出最终答案。使用独立工作空间和精确输入 SHA-256 校验，不向 Kimi 提供论文、参考答案、其他题目或历史响应。
- **真实 API 流：** 运行器 `agent_run_stream_archive.py` 保存实际上游请求与 SSE 响应，按实际模型输出转发经校验的工具调用并记录每次工具结果，请求、响应和终止状态均可核查。没有通过伪造输出补全轨迹。
- **推理参数：** 默认 `reasoning_effort=max`、每请求最多 24,576 completion tokens、整题最多 65,536 completion tokens、12 轮模型请求、24 次工具调用；需要时有限补测使用 `high` 档，输出上限 32,768，工具上限可扩展。实际每题使用的参数以 `evaluation/result.json` 中的 `parameters` 为准，全部入选题实际取得 `complete=true` 和 `finish_reason=stop`。
- **独立 verifier：** GPT-6.1 Sol High，比较已完成的最终回答与标准答案及解答，适用数值误差与等价形式时予以容许。仅当真实末端回答完整、输入和引用材料哈希一致、核验结论有效时记录 Y/N。`Y` 是正确、`N` 是 stump；运行错误、输出或工具上限截断不计入此样本。

### Scientific Agent tools（13 项）

| Tool | 能力 |
|---|---|
| `calculate` | 精确算术、高精度求值、代入与常用函数 |
| `symbolic` | 微分、积分、极限、级数、因式分解、符号求解 |
| `matrix` | 矩阵运算、行列式、秩、求逆、线性系统、特征值、SVD、梯度、Jacobian、Hessian |
| `numeric` | 数值积分、求根、导数、一维优化 |
| `statistics` | 描述统计、置信区间、相关、回归、常用概率分布 |
| `fit_interpolate` | 拟合、线性及样条插值 |
| `data_table` | 经批准的数据表、CSV/TSV 查看与汇总 |
| `list_inputs` | 查看该题已提供的输入文件 |
| `image_info` | 图像尺寸、像素坐标检查 |
| `image_crop` | 局部裁切放大，返回 PNG |
| `pixel_to_data` | 线性/对数坐标轴校准及像素读数误差 |
| `chart_digitize` | 基于图表区域和颜色提取近似曲线/散点 |
| `plot` | 数值图形绘制 |

工具由本机 SymPy、NumPy、SciPy、Pillow 等确定性库提供，通过 MCP 调用。工具可用不代表每题实际调用了工具；实际次数可在 `result.json` 和 `mcp-audit.jsonl` 查看。该配置没有任意程序执行、网络检索、通用 shell 或任意文件读取权限。

## 学科分布

| 行号 | 学科 | 图形信息 |
|---|---|---|
| 35 | Organic chemistry / NMR | 反应物、候选产物的分子拓扑和表征数据 |
| 175 | Mathematics / graph theory | 非规则图中的路径和分支连接 |
| 202 | Machine learning / AI | 多层信息流有向连接图 |
| 253 | Mathematics / discrete geometry | 多种 polyomino 空间形状 |
| 258 | Theoretical computer science | 标号图和实际连边的收缩过程 |
| 268 | Mathematics / combinatorial optimization | 网格缺边和两类终端的空间布局 |
| 270 | Theoretical computer science | 有向图结构与流式算法性质 |
| 271 | Quantum information / graph structures | 不同颜色的连接以及局部图结构 |
| 383 | Applied physics / electromagnetics | 平行板波导、槽偶极的空间位置和方向 |

